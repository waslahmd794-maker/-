package com.waqti.study

import android.app.Activity
import android.os.Bundle
import android.os.CountDownTimer
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import android.content.Context

class MainActivity : Activity() {
    private lateinit var timerText: TextView
    private lateinit var modeText: TextView
    private lateinit var tasksBox: LinearLayout
    private lateinit var progressText: TextView
    private var timer: CountDownTimer? = null
    private var remaining = 25 * 60 * 1000L
    private var breakMode = false
    private var running = false
    private val prefs by lazy { getSharedPreferences("waqti", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        renderTasks()
        updateTimer()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(text: String, size: Float, bold: Boolean=false): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(Color.rgb(30,30,35))
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(24))
            setBackgroundColor(Color.rgb(248,248,252))
        }

        root.addView(tv("وقتي 📚", 28f, true))
        root.addView(tv("نظّم يومك وابدأ بخطوة صغيرة.", 15f).apply { setTextColor(Color.DKGRAY) })

        val timerCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(18), dp(12), dp(18))
            setBackgroundColor(Color.WHITE)
        }
        modeText = tv("📚 جلسة مذاكرة", 15f, true)
        modeText.gravity = Gravity.CENTER
        timerText = tv("25:00", 52f, true)
        timerText.gravity = Gravity.CENTER
        progressText = tv("0% مكتمل", 14f, true)
        progressText.gravity = Gravity.CENTER
        timerCard.addView(modeText)
        timerCard.addView(timerText)
        val timerBtns = LinearLayout(this).apply { gravity = Gravity.CENTER }
        val start = Button(this).apply { text = "ابدأ" }
        val pause = Button(this).apply { text = "إيقاف" }
        val reset = Button(this).apply { text = "إعادة" }
        timerBtns.addView(start); timerBtns.addView(pause); timerBtns.addView(reset)
        timerCard.addView(timerBtns)
        root.addView(timerCard, LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT).apply { setMargins(0,dp(16),0,dp(16)) })

        start.setOnClickListener { startTimer() }
        pause.setOnClickListener { pauseTimer() }
        reset.setOnClickListener { resetTimer() }

        root.addView(tv("مهام اليوم", 20f, true))
        val form = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val input = EditText(this).apply {
            hint = "مثلاً: رياضيات — حل 10 مسائل"
            textSize = 16f
            singleLine = true
        }
        val add = Button(this).apply { text = "إضافة" }
        form.addView(input, LinearLayout.LayoutParams(0, dp(58), 1f))
        form.addView(add)
        root.addView(form)
        tasksBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(tasksBox)

        add.setOnClickListener {
            val s = input.text.toString().trim()
            if (s.isNotEmpty()) {
                val list = loadTasks().toMutableList()
                list.add("0|$s")
                saveTasks(list)
                input.text.clear()
                renderTasks()
            }
        }

        root.addView(tv("🎯 طريقة بسيطة", 19f, true).apply { setPadding(dp(4),dp(22),dp(4),dp(2)) })
        root.addView(tv("ذاكر 25 دقيقة بتركيز، خذ 5 دقائق راحة، ثم كرر. لا تشترط إنجاز كل شيء؛ المهم تبدأ.", 15f).apply { setTextColor(Color.DKGRAY) })

        scroll.addView(root)
        setContentView(scroll)
    }

    private fun loadTasks(): List<String> = prefs.getStringSet("tasks", emptySet())!!.toList()

    private fun saveTasks(list: List<String>) {
        prefs.edit().putStringSet("tasks", list.toSet()).apply()
    }

    private fun renderTasks() {
        if (!::tasksBox.isInitialized) return
        tasksBox.removeAllViews()
        val list = loadTasks().toMutableList()
        var done = 0
        list.forEachIndexed { index, raw ->
            val p = raw.split("|", limit=2)
            val checked = p.getOrNull(0) == "1"
            if (checked) done++
            val row = LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(8),dp(4),dp(4),dp(4))
                setBackgroundColor(Color.WHITE)
            }
            val cb = CheckBox(this).apply { isChecked = checked }
            val label = tv(p.getOrNull(1) ?: "", 15f)
            val del = Button(this).apply { text = "حذف" }
            row.addView(cb)
            row.addView(label, LinearLayout.LayoutParams(0,dp(58),1f))
            row.addView(del)
            tasksBox.addView(row, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0,dp(5),0,0) })
            cb.setOnCheckedChangeListener { _, isChecked ->
                val new = loadTasks().toMutableList()
                val text = new.getOrNull(index)?.split("|", limit=2)?.getOrNull(1) ?: return@setOnCheckedChangeListener
                new[index] = "${if(isChecked) 1 else 0}|$text"
                saveTasks(new); renderTasks()
            }
            del.setOnClickListener {
                val new = loadTasks().toMutableList()
                if (index < new.size) new.removeAt(index)
                saveTasks(new); renderTasks()
            }
        }
        progressText.text = "${if(list.isEmpty()) 0 else done*100/list.size}% مكتمل"
    }

    private fun startTimer() {
        if (running) return
        running = true
        timer = object : CountDownTimer(remaining, 1000) {
            override fun onTick(ms: Long) { remaining = ms; updateTimer() }
            override fun onFinish() {
                running = false
                breakMode = !breakMode
                remaining = if (breakMode) 5*60*1000L else 25*60*1000L
                updateTimer()
                Toast.makeText(this@MainActivity, if(breakMode) "وقت الراحة ☕" else "ارجع للمذاكرة 📚", Toast.LENGTH_LONG).show()
            }
        }.start()
    }

    private fun pauseTimer() { timer?.cancel(); timer=null; running=false }

    private fun resetTimer() {
        pauseTimer()
        breakMode=false
        remaining=25*60*1000L
        updateTimer()
    }

    private fun updateTimer() {
        val total = remaining.coerceAtLeast(0L)/1000
        timerText.text = String.format("%02d:%02d", total/60, total%60)
        modeText.text = if (breakMode) "☕ وقت الراحة" else "📚 جلسة مذاكرة"
    }

    override fun onDestroy() {
        timer?.cancel()
        super.onDestroy()
    }
}
